package com.dynamicreportmaven1;

import java.util.List;

import net.sf.dynamicreports.report.exception.DRException;
import net.sf.jasperreports.engine.JRException;

public class Main {
    public static void main(String[] args) throws DRException, JRException {
        EmployeeData employeeData = new EmployeeData();
        List<Employee> employees = employeeData.getEmployees();

        ReportGenerator reportGenerator = new ReportGenerator();
        reportGenerator.generateReport(employees);
    }
}
