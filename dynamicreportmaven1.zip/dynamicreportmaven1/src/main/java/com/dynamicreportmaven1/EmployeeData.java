package com.dynamicreportmaven1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeData {
    public List<Employee> getEmployees() {
        List<Employee> employees = new ArrayList<>();
        String query = "SELECT * FROM students";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String email = rs.getString("email");
                String first_name = rs.getString("first_name");
                String last_name = rs.getString("last_name");

                employees.add(new Employee(id, email, first_name, last_name));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }
}
