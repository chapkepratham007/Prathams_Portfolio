package com.dynamicreportmaven1;

import java.awt.Color;
import java.io.File;

import java.util.List;

import net.sf.dynamicreports.jasper.builder.JasperReportBuilder;
import net.sf.dynamicreports.report.builder.DynamicReports;
import net.sf.dynamicreports.report.builder.component.ImageBuilder;
import net.sf.dynamicreports.report.exception.DRException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

public class ReportGenerator {

    public void generateReport(List<Employee> employees) throws JRException, DRException {
        try {
            // Load the image (logo) for the report
            String logoPath = "D:\\Techexcel\\logo.png"; // Correct the path to your logo file
            if (!new File(logoPath).exists()) {
                System.out.println("Logo file not found at the given path.");
                return;
            }

            // Define the logo component using DynamicReports.cmp.image() method
            ImageBuilder logo = DynamicReports.cmp.image(logoPath) // Pass the image path as a String
                    .setFixedDimension(100, 50); // Adjust the size as needed

            // Other company details (replace with dynamic data if necessary)
            String companyInfoLeft = "TORUS FINANCIAL MARKETS PRIVATE LIMITED";
            String companyInfoRight = "Date: 13/12/2024";
            String address = "KULDEEP KUMAR\nS/O: SHRIRAM GRAM.JARAULI JARHULI\nKANPUR DEHAT (Uttar Pradesh) 209301\nINDIA";
            String customerDetails = "Dear KULDEEP KUMAR\nAs requested by you, necessary changes have been carried out in your demat account (1209480000015166), as given below:";

            // Building the report
            JasperReportBuilder report = DynamicReports.report()
                    .setColumnTitleStyle(DynamicReports.stl.style().bold().setBackgroundColor(Color.LIGHT_GRAY))
                    .columns(
                            DynamicReports.col.column("ID", "id", Integer.class), // Integer field
                            DynamicReports.col.column("Email", "email", String.class), // String field
                            DynamicReports.col.column("First Name", "first_name", String.class), // String field
                            DynamicReports.col.column("Last Name", "last_name", String.class) // String field
                    )
                    .title(
                            // Horizontal list with logo on the left and company info on the right
                            DynamicReports.cmp.horizontalList()
                                .add(logo) // Add logo on the left side
                                .add(DynamicReports.cmp.text(companyInfoLeft).setStyle(DynamicReports.stl.style().bold()))
                                .add(DynamicReports.cmp.text(companyInfoRight).setStyle(DynamicReports.stl.style().bold().setFontSize(10)))
                    )
                    .addTitle(DynamicReports.cmp.text(customerDetails).setStyle(DynamicReports.stl.style().bold().setFontSize(12)))
                    .addTitle(DynamicReports.cmp.text(address).setStyle(DynamicReports.stl.style().setFontSize(10)))
                    .pageFooter(DynamicReports.cmp.pageXofY())
                    .setDataSource(employees); // Pass your data here (list of Employee objects)

            // Create the report
            JasperPrint jasperPrint = report.toJasperPrint();

            // Export the report to PDF
            JasperExportManager.exportReportToPdfFile(jasperPrint, "D:\\Techexcel\\employee_report.pdf");

            System.out.println("Report generated successfully.");
        } catch (JRException e) {
            e.printStackTrace();
        }
    }
}
